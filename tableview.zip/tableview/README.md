# tableview

1.实现表格tableViewCell里嵌套collectionView  …

2.解决collectionView的tableHeaderView,tableFooterView
