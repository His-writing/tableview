
#import "Common.h"

const int ROOKIE_CELL_HEIGHT = 135;
const int ITEM_PADDING = 10;
// 弹幕默认字体大小
const double DANMU_FONT_SIZE = 15;
// 弹幕字体最小
const double DANMU_FONT_MAXSIZE = 22;
// 弹幕字体最大
const double DANMU_FONT_MINISIZE = 8;
// 弹幕默认透明度
const double DANMU_ALPHA = 1;


NSString * const COLLECTION_IDENTIFIER = @"recommendCollectionCell";


