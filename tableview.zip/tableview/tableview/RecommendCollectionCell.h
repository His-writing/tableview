

#import <UIKit/UIKit.h>
@class DYRoom;

@interface RecommendCollectionCell : UICollectionViewCell
@property (nonatomic, strong) DYRoom *room;
@end
