#import <UIKit/UIKit.h>

@interface RecommendCollectionFlowLayout : UICollectionViewFlowLayout

@end
